﻿# DBC AutoAnnotation

Auto-create and place tags, room area tags and simple dimensions for Doors, Windows and Rooms using pyRevit.

Install
1. Run this installer script which copies the extension to:
   %APPDATA%\pyRevit\Extensions\DBC_AutoAnnotation.extension
2. Restart Revit or use the pyRevit tab -> Reload.
3. Open a Revit view and use the DBC AutoAnnotation tools under the pyRevit tab.

Notes
- Test on a sample project first.
- If Revit runs elevated (Run as administrator), install must be made under the same elevated user's AppData or run Revit normally.
