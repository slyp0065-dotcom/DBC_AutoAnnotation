﻿# DBC Area Tag: create room tags for rooms visible in active view
import os, json, traceback, clr
clr.AddReference("System.Windows.Forms")
from System.Windows.Forms import MessageBox
from Autodesk.Revit.UI import TaskDialog
from Autodesk.Revit.DB import FilteredElementCollector, Room, RoomTag, Transaction, ElementId, FamilySymbol

APPDATA = os.environ.get("APPDATA")
SETTINGS_DIR = os.path.join(APPDATA, "DBC_AutoAnnotation")
SETTINGS_FILE = os.path.join(SETTINGS_DIR, "settings.json")

try:
    uidoc = __revit__.ActiveUIDocument
    doc = uidoc.Document
except:
    TaskDialog.Show("DBC AreaTag","Run from pyRevit inside Revit.")
    raise SystemExit()

rooms = list(FilteredElementCollector(doc, doc.ActiveView.Id).OfClass(Room).WhereElementIsNotElementType())
if not rooms:
    TaskDialog.Show("DBC AreaTag","No rooms visible in the active view.")
    raise SystemExit()

tag_types = list(FilteredElementCollector(doc).OfClass(FamilySymbol).ToElements())
room_tag_types = [t for t in tag_types if "Room" in (t.Family.Name if t.Family else "") or "Room" in (t.Name if t.Name else "")]
tagTypeId = room_tag_types[0].Id if room_tag_types else None

count = len(rooms)
if MessageBox.Show("Create room tags for {0} rooms visible in this view?".format(count), "DBC AreaTag", MessageBoxButtons.YesNo) != MessageBoxButtons.Yes:
    raise SystemExit()

t = Transaction(doc, "DBC AutoAnnotation - Create Room Tags")
try:
    t.Start()
    created = 0
    for r in rooms:
        try:
            try:
                p = r.Location.Point
            except:
                bb = r.get_BoundingBox(doc.ActiveView) or r.get_BoundingBox(None)
                if bb:
                    p = (bb.Min + bb.Max) * 0.5
                else:
                    continue
            if tagTypeId:
                RoomTag.Create(doc, ElementId(tagTypeId), doc.ActiveView.Id, r.Id, p)
                created += 1
        except Exception:
            continue
    t.Commit()
    TaskDialog.Show("DBC AreaTag", "Room tagging finished. Created: {0}".format(created))
except Exception as ex:
    try: t.RollBack()
    except: pass
    TaskDialog.Show("DBC AreaTag", "Failed: {0}".format(str(ex)))
    raise
