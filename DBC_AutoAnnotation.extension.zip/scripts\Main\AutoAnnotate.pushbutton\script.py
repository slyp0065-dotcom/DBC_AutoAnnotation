﻿# DBC AutoAnnotate - batch tag Doors/Windows/Rooms with preview and safe creation
import os, json, math, traceback, clr
clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")
from System.Windows.Forms import (Form, Label, Button, CheckedListBox, ComboBox, MessageBox, Application, DialogResult, CheckBox)
from System.Drawing import Point, Size
from Autodesk.Revit.UI import TaskDialog
from Autodesk.Revit.DB import (FilteredElementCollector, BuiltInCategory, Room, IndependentTag, Reference, TagOrientation, XYZ, Transaction, FamilySymbol, ElementId)

APPDATA = os.environ.get("APPDATA")
SETTINGS_DIR = os.path.join(APPDATA, "DBC_AutoAnnotation")
SETTINGS_FILE = os.path.join(SETTINGS_DIR, "settings.json")

DEFAULT_SETTINGS = {
    "tag_offset_mm": 50,
    "use_leader_by_default": True,
    "duplicate_distance_mm": 50,
    "door_tag_type_id": None,
    "window_tag_type_id": None,
    "room_tag_type_id": None
}

def ensure_settings():
    try:
        if not os.path.isdir(SETTINGS_DIR):
            os.makedirs(SETTINGS_DIR)
        if not os.path.isfile(SETTINGS_FILE):
            with open(SETTINGS_FILE, "w") as f:
                json.dump(DEFAULT_SETTINGS, f, indent=2)
            return DEFAULT_SETTINGS.copy()
        with open(SETTINGS_FILE, "r") as f:
            s = json.load(f)
            for k,v in DEFAULT_SETTINGS.items():
                if k not in s:
                    s[k] = v
            return s
    except:
        return DEFAULT_SETTINGS.copy()

def save_settings(s):
    try:
        with open(SETTINGS_FILE, "w") as f:
            json.dump(s, f, indent=2)
        return True
    except:
        return False

def mm_to_feet(mm): return mm / 304.8

try:
    uidoc = __revit__.ActiveUIDocument
    doc = uidoc.Document
except Exception:
    TaskDialog.Show("DBC AutoAnnotation", "Run this command from the pyRevit ribbon inside Revit.")
    raise SystemExit()

settings = ensure_settings()
offset_feet = mm_to_feet(settings.get("tag_offset_mm", 50))
dup_dist_feet = mm_to_feet(settings.get("duplicate_distance_mm", 50))

def collect_by_category(cat):
    try:
        collector = FilteredElementCollector(doc, doc.ActiveView.Id)
        if cat == "Doors":
            return list(collector.OfCategory(BuiltInCategory.OST_Doors).WhereElementIsNotElementType())
        elif cat == "Windows":
            return list(collector.OfCategory(BuiltInCategory.OST_Windows).WhereElementIsNotElementType())
        elif cat == "Rooms":
            return list(collector.OfClass(Room).WhereElementIsNotElementType())
        else:
            return []
    except Exception:
        return []

def element_center(elem):
    try:
        loc = getattr(elem, "Location", None)
        if loc is not None:
            if hasattr(loc, "Point"):
                return loc.Point
            elif hasattr(loc, "Curve"):
                c = loc.Curve
                if c is not None:
                    return c.Evaluate(0.5, True)
    except:
        pass
    try:
        bb = elem.get_BoundingBox(doc.ActiveView)
        if bb is not None:
            return (bb.Min + bb.Max) * 0.5
    except:
        pass
    try:
        bb = elem.get_BoundingBox(None)
        if bb is not None:
            return (bb.Min + bb.Max) * 0.5
    except:
        pass
    return XYZ(0,0,0)

def compute_tag_position(elem, offset = offset_feet):
    center = element_center(elem)
    try:
        # Use the view right direction when possible (plan/3D); fall back to X offset
        vr = getattr(doc.ActiveView, "RightDirection", None)
        if vr:
            candidate = XYZ(center.X + vr.X * offset, center.Y + vr.Y * offset, center.Z + vr.Z * offset)
            return candidate
    except:
        pass
    return XYZ(center.X + offset, center.Y, center.Z)

def is_duplicate(candidate_pos, threshold = dup_dist_feet):
    try:
        tags = FilteredElementCollector(doc, doc.ActiveView.Id).OfClass(IndependentTag).WhereElementIsNotElementType().ToElements()
        for t in tags:
            try:
                head = t.TagHeadPosition
                if head is None:
                    continue
                dx = head.X - candidate_pos.X
                dy = head.Y - candidate_pos.Y
                dz = head.Z - candidate_pos.Z
                dist = math.sqrt(dx*dx + dy*dy + dz*dz)
                if dist <= threshold:
                    return True, t
            except:
                continue
    except:
        pass
    return False, None

def create_independent_tag_for_element(elem, tagTypeId=None, useLeader=True):
    pos = compute_tag_position(elem)
    ref = Reference(elem)
    try:
        if tagTypeId:
            tag = IndependentTag.Create(doc, ElementId(tagTypeId), doc.ActiveView.Id, ref, useLeader, TagOrientation.Horizontal, pos)
            return tag
    except:
        pass
    try:
        tag = IndependentTag.Create(doc, doc.ActiveView.Id, ref, useLeader, TagOrientation.Horizontal, pos)
        return tag
    except Exception as ex:
        raise

def gather_tag_types():
    syms = FilteredElementCollector(doc).OfClass(FamilySymbol).ToElements()
    tag_symbols = []
    for s in syms:
        try:
            family = s.Family
            famname = family.Name if family is not None else ""
            tag_symbols.append((s.Id.IntegerValue, famname + " - " + s.Name))
        except:
            continue
    tag_symbols.sort(key=lambda t: t[1].lower())
    return tag_symbols

class PreviewForm(Form):
    def __init__(self):
        self.Text = "DBC AutoAnnotate — Preview & Tagging"
        self.Size = Size(820,640)
        self.StartPosition = 1

        lblView = Label(Text="Active view: {0}".format(doc.ActiveView.Name), Location=Point(10,8), Size=Size(700,20))
        self.Controls.Add(lblView)

        lblCat = Label(Text="Category:", Location=Point(10,36), Size=Size(80,20))
        self.cmbCat = ComboBox(Location=Point(95,34), Size=Size(140,24))
        self.cmbCat.Items.Add("Doors")
        self.cmbCat.Items.Add("Windows")
        self.cmbCat.Items.Add("Rooms")
        self.cmbCat.SelectedIndex = 0

        self.Controls.Add(lblCat)
        self.Controls.Add(self.cmbCat)

        lblTagType = Label(Text="Tag type:", Location=Point(260,36), Size=Size(80,20))
        self.cmbTagType = ComboBox(Location=Point(340,34), Size=Size(420,24))
        self.Controls.Add(lblTagType)
        self.Controls.Add(self.cmbTagType)

        self.chkLeader = CheckBox(Text="Use leader when creating tags", Location=Point(10,64), Size=Size(240,24))
        self.chkLeader.Checked = bool(settings.get("use_leader_by_default", True))
        self.Controls.Add(self.chkLeader)

        self.clb = CheckedListBox(Location=Point(10,100), Size=Size(780,460))
        self.Controls.Add(self.clb)

        btnTag = Button(Text="Create Tags (selected)", Location=Point(10,560), Size=Size(220,36))
        btnClose = Button(Text="Close", Location=Point(250,560), Size=Size(120,36))
        btnRefresh = Button(Text="Refresh", Location=Point(390,560), Size=Size(120,36))

        btnTag.Click += self.on_tag
        btnClose.Click += self.on_close
        btnRefresh.Click += self.on_refresh

        self.Controls.Add(btnTag)
        self.Controls.Add(btnClose)
        self.Controls.Add(btnRefresh)

        self.tag_types = gather_tag_types()
        for t in self.tag_types:
            self.cmbTagType.Items.Add(t[1])

        self.load_elements()

    def load_elements(self):
        cat = self.cmbCat.SelectedItem
        elems = collect_by_category(cat)
        self.elements = elems
        self.clb.Items.Clear()
        for e in elems:
            try:
                name = e.Category.Name if e.Category is not None else e.GetType().Name
                display = "{0} (Id {1})".format(name, e.Id.IntegerValue)
            except:
                display = "Element Id {0}".format(e.Id.IntegerValue)
            self.clb.Items.Add(display, True)

    def on_refresh(self, sender, args):
        self.load_elements()

    def on_close(self, sender, args):
        self.DialogResult = DialogResult.Cancel
        self.Close()

    def on_tag(self, sender, args):
        sel_indices = [i for i in range(self.clb.Items.Count) if self.clb.GetItemChecked(i)]
        if not sel_indices:
            MessageBox.Show("No elements selected.", "DBC AutoAnnotation")
            return
        selected = [self.elements[i] for i in sel_indices]
        tagTypeId = None
        try:
            if self.cmbTagType.SelectedIndex >= 0:
                tagTypeId = self.tag_types[self.cmbTagType.SelectedIndex][0]
        except:
            tagTypeId = None
        useLeader = bool(self.chkLeader.Checked)

        confirm = MessageBox.Show("Create tags for {0} selected elements?\nThis will modify the model inside a Revit Transaction.".format(len(selected)),
                                  "Confirm", MessageBoxButtons.YesNo)
        if confirm != MessageBoxButtons.Yes:
            return

        successes = []
        failures = []
        skipped = []
        t = Transaction(doc, "DBC AutoAnnotation - Create Tags")
        try:
            t.Start()
            for elem in selected:
                try:
                    candidate = compute_tag_position(elem)
                    dup, existing = is_duplicate(candidate, dup_dist_feet)
                    if dup:
                        skipped.append((elem.Id.IntegerValue, existing.Id.IntegerValue if existing is not None else None))
                        continue
                    tag = create_independent_tag_for_element(elem, tagTypeId, useLeader)
                    successes.append(tag.Id.IntegerValue if tag is not None else None)
                except Exception as ex:
                    failures.append((elem.Id.IntegerValue, str(ex)))
            t.Commit()
        except Exception as ex:
            try:
                t.RollBack()
            except:
                pass
            MessageBox.Show("Tagging failed and transaction rolled back: {0}".format(str(ex)), "DBC AutoAnnotation")
            return

        res = "Tagging complete.\nSuccessful: {0}\nSkipped (duplicates): {1}\nFailed: {2}".format(len(successes), len(skipped), len(failures))
        MessageBox.Show(res, "DBC AutoAnnotation")
        self.DialogResult = DialogResult.OK
        self.Close()

try:
    form = PreviewForm()
    Application.Run(form)
except Exception as e:
    TaskDialog.Show("DBC AutoAnnotation", "Unexpected error:\\n{0}\\n\\n{1}".format(str(e), traceback.format_exc()))
    raise
