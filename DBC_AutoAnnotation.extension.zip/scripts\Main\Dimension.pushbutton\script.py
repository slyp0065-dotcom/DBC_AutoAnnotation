﻿# DBC Dimension helper - picks two references (edges) and creates a linear dimension
import clr, traceback, os
clr.AddReference("System.Windows.Forms")
from System.Windows.Forms import MessageBox
from Autodesk.Revit.UI import TaskDialog
from Autodesk.Revit.DB import (ReferenceArray, Line, Transaction, ElementId, XYZ, SketchPlane, Plane)

try:
    uidoc = __revit__.ActiveUIDocument
    doc = uidoc.Document
except:
    TaskDialog.Show("DBC Dimension","Run from pyRevit inside Revit.")
    raise SystemExit()

sel = uidoc.Selection
TaskDialog.Show("DBC Dimension","Pick two element edges or points to dimension (you will be prompted twice).")

try:
    ref1 = sel.PickObject(Autodesk.Revit.UI.Selection.ObjectType.Edge, "Select first edge or element")
    ref2 = sel.PickObject(Autodesk.Revit.UI.Selection.ObjectType.Edge, "Select second edge or element")
except Exception as e:
    TaskDialog.Show("DBC Dimension", "Selection cancelled or invalid: {0}".format(str(e)))
    raise SystemExit()

try:
    p1 = uidoc.Document.GetElement(ref1.ElementId).get_BoundingBox(uidoc.ActiveView).Center
except:
    p1 = XYZ(0,0,0)
try:
    p2 = uidoc.Document.GetElement(ref2.ElementId).get_BoundingBox(uidoc.ActiveView).Center
except:
    p2 = XYZ(1,0,0)

line = Line.CreateBound(p1, p2)
t = Transaction(doc, "DBC AutoAnnotation - Dimension")
try:
    t.Start()
    sp = SketchPlane.Create(doc, Plane.CreateByNormalAndOrigin(doc.ActiveView.ViewDirection, p1))
    refs = ReferenceArray()
    refs.Append(ref1)
    refs.Append(ref2)
    dim = doc.Create.NewDimension(doc.ActiveView, line, refs)
    t.Commit()
    TaskDialog.Show("DBC Dimension", "Dimension created.")
except Exception as ex:
    try: t.RollBack()
    except: pass
    TaskDialog.Show("DBC Dimension", "Failed to create dimension: {0}".format(str(ex)))
    raise
