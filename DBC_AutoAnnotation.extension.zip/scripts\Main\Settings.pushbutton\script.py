﻿# Simple settings editor for DBC AutoAnnotation
import os, json, clr
clr.AddReference("System.Windows.Forms")
from System.Windows.Forms import Form, Label, TextBox, Button, CheckBox, Application, DialogResult
from System.Drawing import Point, Size
from Autodesk.Revit.UI import TaskDialog

APPDATA = os.environ.get("APPDATA")
SETTINGS_DIR = os.path.join(APPDATA, "DBC_AutoAnnotation")
SETTINGS_FILE = os.path.join(SETTINGS_DIR, "settings.json")
DEFAULTS = {"tag_offset_mm":50,"duplicate_distance_mm":50,"use_leader_by_default":True}

def ensure():
    if not os.path.isdir(SETTINGS_DIR): os.makedirs(SETTINGS_DIR)
    if not os.path.isfile(SETTINGS_FILE):
        with open(SETTINGS_FILE,"w") as f:
            json.dump(DEFAULTS, f)

ensure()
with open(SETTINGS_FILE,"r") as f:
    data = json.load(f)

class FormSettings(Form):
    def __init__(self):
        self.Text = "DBC AutoAnnotation - Settings"
        self.Size = Size(380,200)
        Label(Text="Tag offset (mm):", Location=Point(10,10), Size=Size(120,23), Parent=self)
        self.txtOffset = TextBox(Text=str(data.get("tag_offset_mm",50)), Location=Point(140,10), Size=Size(200,23), Parent=self)
        Label(Text="Duplicate distance (mm):", Location=Point(10,45), Size=Size(120,23), Parent=self)
        self.txtDup = TextBox(Text=str(data.get("duplicate_distance_mm",50)), Location=Point(140,45), Size=Size(200,23), Parent=self)
        self.chkLeader = CheckBox(Text="Use leader by default", Location=Point(10,80), Size=Size(200,23), Parent=self)
        self.chkLeader.Checked = bool(data.get("use_leader_by_default",True))
        btnSave = Button(Text="Save", Location=Point(140,120), Size=Size(80,30), Parent=self)
        btnCancel = Button(Text="Cancel", Location=Point(240,120), Size=Size(80,30), Parent=self)
        btnSave.Click += self.on_save
        btnCancel.Click += self.on_close

    def on_save(self, sender, args):
        try:
            data["tag_offset_mm"] = int(self.txtOffset.Text.strip())
            data["duplicate_distance_mm"] = int(self.txtDup.Text.strip())
            data["use_leader_by_default"] = bool(self.chkLeader.Checked)
            with open(SETTINGS_FILE,"w") as f:
                json.dump(data,f,indent=2)
            self.DialogResult = DialogResult.OK
            self.Close()
            TaskDialog.Show("Settings","Settings saved.")
        except Exception as e:
            TaskDialog.Show("Settings","Failed to save: {0}".format(str(e)))

    def on_close(self, sender, args):
        self.DialogResult = DialogResult.Cancel
        self.Close()

form = FormSettings()
Application.Run(form)
